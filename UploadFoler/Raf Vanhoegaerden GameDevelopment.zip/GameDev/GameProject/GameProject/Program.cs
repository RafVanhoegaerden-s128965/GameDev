﻿
using var game = new GameProject.Game1();
game.Run();
