﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameProject.Settings
{
    public class Screen
    {
        static public int Width = 1920;
        static public int Height = 1080;
    }
}
